package com.example.fyrflyuser.utils;

import com.google.android.gms.maps.model.LatLng;

public class AppConstants {

    public static final String LOGIN_KEY = "";
    public static final String USER_ID = "userId";
    public static final String USER_NAME = "user_name";
    public static final String ADDRESS_FROM = "from";
    public static final String ADDRESS_TO = "to";
    public static final String LATLONG = "";
    public static final String latitude = "";
    public static final String longitude = "";
    public static final String PHONE = "userId";
    public static final String COUNTRY_NAME = "userId";
    public static final String USER_INFO = "USER_INFO";
    public static final String LOGIN_STATUS = "loginStatus";
    public static final String LOGIN_TOKEN = "LOGIN_TOKEN";
    public static final String SESSION ="SESSION" ;
    public static final String UNIQUE_ID ="UNIQUE_ID" ;

    public static final String MOBILE_NUMBER ="" ;

    public static final String USER_IMAGE = "";

}
